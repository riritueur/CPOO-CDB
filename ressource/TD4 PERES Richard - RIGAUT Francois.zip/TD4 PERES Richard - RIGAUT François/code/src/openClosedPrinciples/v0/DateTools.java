package openClosedPrinciples.v0;

import java.time.LocalDate;

public class DateTools {

	public static LocalDate addDays(LocalDate date, int nbJour) {
		return date.plusDays(nbJour);
		}
	
	public static LocalDate[] getDays(LocalDate date, int nbJour) {
		int i = 0;
		LocalDate[] dates = new LocalDate[nbJour];
		dates[i] = date;
		i+=1;
		while (i < nbJour) {
			dates[i] = addDays(date,i);
			i++;
		}
		return dates;
	}
	
}
