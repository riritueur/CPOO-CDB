package openClosedPrinciples.v0;

import java.util.ArrayList;

//To create a trip corresponding to a description
public class TravelOrganizer {
	
	ArrayList<Service> services = new ArrayList<Service>();
	
	public Trip createATrip(Description d){
		Trip trip = new Trip(d);
		for(Service s : services){
			Item item = s.find(d);
			trip.add(item);
		}
		return trip;
	}
	
	public void addService(Service s){
		services.add(s);
	}
}
