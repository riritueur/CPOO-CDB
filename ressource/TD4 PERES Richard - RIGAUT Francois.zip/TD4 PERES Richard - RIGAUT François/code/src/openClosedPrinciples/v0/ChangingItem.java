package openClosedPrinciples.v0;

public interface ChangingItem {

	public void changePrice(double ratio);
}
