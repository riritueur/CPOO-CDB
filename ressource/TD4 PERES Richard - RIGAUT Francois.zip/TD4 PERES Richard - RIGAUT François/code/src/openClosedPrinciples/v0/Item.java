package openClosedPrinciples.v0;


public interface Item {
	double getPrice();
}
