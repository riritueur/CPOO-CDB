package openClosedPrinciples.v0;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Random;

public class Flight extends MovingItem {
	private LocalDate departDate;
	private String departAirport;
	private String arrivalAirport;
	private LocalTime departTime;
	public static int id = 0;
	
	public LocalTime getDepartTime() {
		return departTime;
	}
	public void setDepartTime(LocalTime departTime) {
		this.departTime = departTime;
	}
	public Flight(String departAirport) {
		this(-1, LocalDate.now(), LocalTime.now(), departAirport, "Paris");
	}
	public Flight(double price, LocalDate departDate, LocalTime departTime, String departAirport, String arrivalAirport) {
		// Le nom d'un flight est sous la forme f + un id qui s'incr�mente
		super("f"+Integer.toString(id),price);
		id++;
		this.departDate = departDate;
		this.departAirport = departAirport;
		this.arrivalAirport = arrivalAirport;
		this.departTime= departTime;
	}
	public LocalDate getDepartDate() {
		return departDate;
	}
	public void setDepartDate(LocalDate departDate) {
		this.departDate = departDate;
	}
	public String getDepartAirport() {
		return departAirport;
	}
	public void setDepartAirport(String departAirport) {
		this.departAirport = departAirport;
	}

	public String getArrivalAirport() {
		return arrivalAirport;
	}
	public void setArrivalAirport(String arrivalAirport) {
		this.arrivalAirport = arrivalAirport;
	}	
	
	//to test
	public boolean match(LocalDate d, String from, String to) {
			return getDepartDate().equals(d) && getDepartAirport().equals(from) && getArrivalAirport().equals(to);
	}
}
