package openClosedPrinciples.v0;

import java.time.LocalDate;
import java.util.ArrayList;

public class CarRentalService implements Service{

	private ArrayList<Car> cars;
	
	public CarRentalService(ArrayList<Car> cars) {
		super();
		this.cars = cars;
	}

		

	public ArrayList<Car> getAvailableCars(LocalDate d, int duration) {
		ArrayList<Car> availableCars = new ArrayList<Car>();
		LocalDate[] dates = DateTools.getDays(d, duration);
		for (Car c : cars) {
			if (c.isAvailable(dates)) {
				availableCars.add(c);
			}
		}
		return availableCars;
		
	}
	
	
	public CarRental book(Car c, LocalDate d, int duration) {
		if (! (cars.contains(c)) )
			return null;
		LocalDate[] dates = DateTools.getDays(d, duration);
		CarRental carRental= null;
		if (c.isAvailable(dates)) {
			carRental = new CarRental(c, d, duration);
		}
		return carRental;
	}



	@Override
	public Item find(Description d) {
		ArrayList<Car> cars = getAvailableCars(d.getDate(),d.getDuration());
		ArrayList<CarRental> rentals = new ArrayList<CarRental>();
		for(Car c : cars){
			rentals.add(book(c,d.getDate(),d.getDuration()));
		}
		return Tools.cheaper(rentals);
	}
	
	

}
