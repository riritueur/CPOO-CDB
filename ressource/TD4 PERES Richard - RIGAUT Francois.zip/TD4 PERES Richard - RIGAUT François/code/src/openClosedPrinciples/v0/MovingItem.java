package openClosedPrinciples.v0;

import java.util.Random;

import openClosedPrinciples.v0.Item;

public class MovingItem implements ChangingItem, Item {

	private double price = -1;
	private String name;

	public MovingItem(String name,double price) {
		this.price = price;
		this.name = name;
	}

	@Override
	public void changePrice(double ratio) {
		price = price*ratio;
	}
	
	public double getPrice() {
		if (price == -1) {
			double start = 10;
			double end = 1000;
			double random = new Random().nextDouble();
			price = start + (random * (end - start));
			}
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public String getName(){return name;}
}
