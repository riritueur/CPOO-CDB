package openClosedPrinciples.v0;

import java.time.LocalDate;

public class CarRental implements Item{

	private String carNumber;
	private double dayPrice;
	private int duration;
	private LocalDate beginDate;
	
	
	private CarRental(String carNumber, double dayPrice, int duration, LocalDate beginDate) {
		super();
		this.carNumber = carNumber;
		this.dayPrice = dayPrice;
		this.duration = duration;
		this.beginDate = beginDate;
	}
	
	public CarRental(Car c, LocalDate beginDate, int duration) {
		//On considere que le prix de la location ne doit plus bouger meme si le prix de la voiture change
		this(c.getNumberPlate(),c.getDayPrice(),duration,beginDate);
		c.book(beginDate, duration);
	}

	public String getCarNumber() {
		return carNumber;
	}
	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public LocalDate getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(LocalDate beginDate) {
		this.beginDate = beginDate;
	}
	
	//todo : work on reduction according to duration and month
	public double getPrice() {
		return dayPrice*duration;
	}
	

}
