package openClosedPrinciples.v0;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Timer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.TimerTask;


public class FlightService implements Service{

	private ArrayList<Flight> flights = new ArrayList<Flight>();
	
	public FlightService(ArrayList<Flight> flights) {
		this.flights = flights;
	}
	
	
	public ArrayList<Flight> getFlightsCheaperThan(double price) {
		Stream<Flight> parallelStream = flights.parallelStream(); 
		Stream<Flight> results = parallelStream.filter(f -> f.getPrice() < price);
		return results.collect(Collectors.toCollection(ArrayList::new));
	}
	
	
	public ArrayList<Flight> getFlights(LocalDate d) {
		Stream<Flight> parallelStream = flights.parallelStream(); 
		Stream<Flight> results = parallelStream.filter(f -> (f.getDepartDate().equals(d)) ) ;
		return results.collect(Collectors.toCollection(ArrayList::new));
	}
	
	//To test
	public ArrayList<Flight> getFlights(LocalDate d, String from, String to) {
		Stream<Flight> parallelStream = flights.parallelStream(); 
		Stream<Flight> results = parallelStream.filter(f -> 
		             f.match(d, from, to))  ;
		return results.collect(Collectors.toCollection(ArrayList::new));
	}
	
	public ArrayList<Flight> getAllFlights(){
		return this.flights;
	}

	//Pour trouver le vol le moins cher correspondant � une description
	//Les vols changent de prix r�guli�rement
	@Override
	public Item find(Description d) {
		ArrayList<Flight> flights = getFlights(d.getDate(),d.getDepartPlace(),d.getArrivalPlace());
		Item item = Tools.cheaper((flights));
		ChangingPriceTask c = new ChangingPriceTask((ChangingItem)item, 5.0);
		Timer timer = new Timer(true);
		timer.scheduleAtFixedRate(c, 0, 190);
		return item;
	}
	
	
	//Q2 The less expensive flight
	//Q2 Sort Flights
	

	//Sorting using Anonymous Inner class.
/*	public ArrayList<Flight> sortedByPrice()
	Collections.sort(personList, new Comparator<Person>(){
	  public int compare(Person p1, Person p2){
	    return p1.firstName.compareTo(p2.firstName);
	  }
*/
	
	
}
