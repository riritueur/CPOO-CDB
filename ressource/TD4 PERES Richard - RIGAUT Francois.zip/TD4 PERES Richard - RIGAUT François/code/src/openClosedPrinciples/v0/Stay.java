package openClosedPrinciples.v0;

import java.time.LocalDate;
import java.util.Date;

public class Stay {

	private LocalDate beginDate;
	private Hotel hotel;
	private int duration;
	
	public Stay(LocalDate begin, int duration, Hotel hotel) {
		beginDate = begin;
		this.duration = duration;
		this.hotel = hotel;
	}

	public double getPrice() {
		return hotel.getNightPrice()*duration;
	}
}
