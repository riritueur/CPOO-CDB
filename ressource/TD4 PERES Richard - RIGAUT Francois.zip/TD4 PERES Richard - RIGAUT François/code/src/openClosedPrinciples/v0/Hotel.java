package openClosedPrinciples.v0;

import java.util.Date;

public class Hotel {
	
	private int nightPrice;
	private String place;
	
	
	public Hotel(int nightPrice, String place) {
		super();
		this.nightPrice = nightPrice;
		this.place = place;
	}


	//todo : manage availability
	public boolean isAvailable(Date d) {
		return true;
	}

	public double getPrice(Date d, int duration) {
		return nightPrice*duration;
	}

	public int getNightPrice() {
		return nightPrice;
	}

	public void setNightPrice(int nightPrice) {
		this.nightPrice = nightPrice;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}
	
	
}
