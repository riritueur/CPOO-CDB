package openClosedPrinciples.v0;

public interface Service {
	public Item find(Description d);
}
