package openClosedPrinciples.v0;

import java.util.ArrayList;
import java.util.Date;

public class HotelService {

	private ArrayList<Hotel> hotels;
	
	//todo 
	public ArrayList<Hotel> getHotels(Date d, String place, int duration) {
		ArrayList<Hotel> availableHotels = new ArrayList<Hotel>();
		for (Hotel hotel : hotels)
				if (hotel.getPlace().equals(place) && hotel.isAvailable(d))
					availableHotels.add(hotel);
		return availableHotels;
		
	}
}
