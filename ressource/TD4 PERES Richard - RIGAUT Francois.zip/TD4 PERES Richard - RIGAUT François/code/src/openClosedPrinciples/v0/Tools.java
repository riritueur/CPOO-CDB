package openClosedPrinciples.v0;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

//Useful tools to work on the lists of items
public class Tools{
	
	public static void sortedByPrice(ArrayList< ?extends Item> object){
		Collections.sort(object, new Comparator<Item>(){
			@Override
			public int compare(Item arg0, Item arg1) {
				return (int)(arg0.getPrice() - arg1.getPrice());
			}
		});
	}
	
	public static Item cheaper(ArrayList< ?extends Item> items){
		sortedByPrice(items);
		return items.get(0);
	}
	
	
}
