package openClosedPrinciples.v0;
import java.util.TimerTask;


/*
 * Based on  https://www.journaldev.com/1050/java-timer-timertask-example
 */
public class ChangingPriceTask extends TimerTask {

	private ChangingItem item;
	private double ratio;
	
	public ChangingPriceTask(ChangingItem item, double ratio) {
		super();
		this.item = item;
		this.ratio = ratio;
	}



    @Override
    public void run() {
      // Just to see 
       // System.out.println("Timer task started at:"+ LocalTime.now());
     	item.changePrice(ratio);
        //System.out.println("Timer task finished at:"+LocalTime.now() );
    }
    
    
   

}