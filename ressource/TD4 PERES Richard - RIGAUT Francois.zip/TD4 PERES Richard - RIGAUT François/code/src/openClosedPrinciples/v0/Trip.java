package openClosedPrinciples.v0;

import java.util.ArrayList;

public class Trip {
	
	Description d;
	ArrayList<Item> items;
	
	public Trip(Description d){
		this.d = d;
	}
	
	public double getPrice(){
		double result = 0;
		for(Item i : items){
			result += i.getPrice();
		}
		return result;
	}
	
	public void add(Item i){
		items.add(i);
	}
}
