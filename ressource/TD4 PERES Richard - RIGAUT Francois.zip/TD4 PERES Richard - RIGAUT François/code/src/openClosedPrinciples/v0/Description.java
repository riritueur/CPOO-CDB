package openClosedPrinciples.v0;

import java.time.LocalDate;

public class Description {

	private LocalDate departDate;
	private String departPlace;
	private String arrivalPlace;
	private int duration;
	
	public Description(LocalDate departD, String dp, String ap, int dur){
		departDate = departD;
		departPlace = dp;
		arrivalPlace = ap;
		duration = dur;
	}
	
	public LocalDate getDate(){return departDate;}
	public String getDepartPlace(){return departPlace;}
	public String getArrivalPlace(){return arrivalPlace;}
	public int getDuration(){return duration;}
}
