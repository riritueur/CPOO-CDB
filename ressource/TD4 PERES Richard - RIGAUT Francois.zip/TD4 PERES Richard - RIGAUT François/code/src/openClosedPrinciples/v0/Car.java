package openClosedPrinciples.v0;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class Car {

	private String numberPlate;
	private HashSet<LocalDate> rentals = new HashSet<LocalDate>();
	private double dayPrice;
	
	
	public Car(String numberPlate, double dayPrice) {
		super();
		this.numberPlate = numberPlate;
		this.dayPrice = dayPrice;
	}
	
	public boolean isAvailable(LocalDate d) {
		return !( rentals.contains(d));
	}
	
	
	//precond : We assume the reservation is made only if the car is available
	protected void book(LocalDate d, int duration) {
		LocalDate[] dates = DateTools.getDays(d, duration);
		for (LocalDate date : dates)
			rentals.add(date);
	}
	


	public String getNumberPlate() {
		return numberPlate;
	}
	public void setNumberPlate(String numberPlate) {
		this.numberPlate = numberPlate;
	}
	public double getDayPrice() {
		return dayPrice;
	}
	public void setDayPrice(double dayPrice) {
		this.dayPrice = dayPrice;
	}
	public Set<LocalDate> getRentals() {
		return rentals;
	}
	public boolean isAvailable(LocalDate[] dates) {
		for (LocalDate d : dates)
			if (! isAvailable(d))
				return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Car [numberPlate=" + numberPlate + ", rentals=" + rentals + ", dayPrice=" + dayPrice + "]";
	}
	
}
