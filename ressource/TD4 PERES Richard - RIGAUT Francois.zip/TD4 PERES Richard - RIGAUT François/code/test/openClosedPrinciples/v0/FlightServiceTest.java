package openClosedPrinciples.v0;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FlightServiceTest {

	FlightService service ;
	@Before
	public void setUp() throws Exception {
		ArrayList<Flight> list = new ArrayList<>();
		list.add(new Flight("Belfort"));
		list.add(new Flight("Nice"));
		list.add(new Flight(100, LocalDate.of(2017, 12, 24), LocalTime.of(7, 45),"Nice", "Paris"));
		list.add(new Flight(150, LocalDate.of(2017, 12, 24), LocalTime.of(9, 30), "Nice", "Paris"));
		list.add(new Flight(150, LocalDate.of(2017, 12, 24), LocalTime.of(18, 30), "Paris", "Nice"));
		service = new FlightService(list);
	}


	@Test
	public void testGetFlights() {
		ArrayList<Flight> flights = service.getFlights(LocalDate.now());
		assertEquals(2, flights.size());
		flights = service.getFlights(LocalDate.of(2017, 12, 24));
		assertEquals(3, flights.size());
	}

	@Test
	public void testGetFlightsCheaperThan() {
		ArrayList<Flight> flights = service.getFlightsCheaperThan(120);
		System.out.println(flights);
		assertTrue(flights.size()<3);
		assertTrue(flights.size()>=1);
		flights = service.getFlightsCheaperThan(160);
		System.out.println(flights);
		assertTrue(flights.size()>=3);
	}
	
	@Test
	public void testSortedByPrice() {
		Tools.sortedByPrice(service.getAllFlights());
		assertTrue(Tools.cheaper(service.getAllFlights()).getPrice() == 100);
	}

}
