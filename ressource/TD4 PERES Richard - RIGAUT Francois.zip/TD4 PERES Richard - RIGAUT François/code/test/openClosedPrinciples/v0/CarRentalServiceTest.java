package openClosedPrinciples.v0;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

public class CarRentalServiceTest {

	CarRentalService service ; 
	Car myCar0 = new Car("1111 AB 06",50);
	Car myCar1 = new Car("1111 AB 75",100);
	Car myCar2 = new Car("1111 AB 83",75);
	LocalDate currentDate;
	
	@Before
	public void setUp() throws Exception {
		 myCar0 = new Car("1111 AB 06",50);
		 myCar1 = new Car("1111 AB 75",100);
		 myCar2 = new Car("1111 AB 83",75);
		service = new CarRentalService( new ArrayList<>(Arrays.asList(myCar0, myCar1, myCar2) )  )  ;
		
	}

	@Test
	public void testGetAvailableCars() {
		ArrayList<Car> possibleCars = service.getAvailableCars(LocalDate.now(), 2);
		assertEquals(3, possibleCars.size());
	}
	
	
	@Test
	public void testBookAnAvalaibleCar() {
		CarRental carRental = service.book(myCar0,LocalDate.of(2017,9,11), 2);
		assertFalse(carRental==null);
		assertEquals(2, myCar0.getRentals().size());
		assertFalse(myCar0.isAvailable(LocalDate.of(2017,9,11)));
		assertFalse(myCar0.isAvailable(LocalDate.of(2017,9,12)));
		assertTrue(myCar0.isAvailable(LocalDate.of(2017,9,13)));
	}
	
	
	@Test
	public void testBookANonAvalaibleCar() {
		CarRental carRental = service.book(myCar0,LocalDate.of(2017,9,11), 2);
		carRental = service.book(myCar0,LocalDate.of(2017,9,12), 2);
		assertTrue(carRental==null);
	}
	
	@Test
	public void testGetNotAvailableCars() {
		CarRental carRental = service.book(myCar0,LocalDate.of(2017,9,11), 2);
		ArrayList<Car> possibleCars = service.getAvailableCars(LocalDate.of(2017,9,11), 2);
		assertEquals(2, possibleCars.size());
		possibleCars = service.getAvailableCars(LocalDate.of(2017,9,12), 2);
		assertEquals(2, possibleCars.size());
		possibleCars = service.getAvailableCars(LocalDate.of(2017,9,13), 2);
		assertEquals(3, possibleCars.size());
	}



}
