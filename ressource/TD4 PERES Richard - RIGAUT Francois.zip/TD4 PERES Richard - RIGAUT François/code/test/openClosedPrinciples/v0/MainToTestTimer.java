package openClosedPrinciples.v0;

import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.IntStream;

/*
 * Based on  https://www.journaldev.com/1050/java-timer-timertask-example
 */

public class MainToTestTimer {

	public static void main(String[] args) {
		MovingItem movingItem = new MovingItem("p0", 10.0);
		// MovingPayingItem MovingPayingItem2 = new MovingPayingItem("p1", 2.0);
		TimerTask timerTask = new ChangingPriceTask(movingItem, 5);
		// TimerTask timerTask2 = new ChangingPriceTask(MovingPayingItem2,3);
		// running timer task as daemon thread
		Timer timer = new Timer(true);
		timer.scheduleAtFixedRate(timerTask, 0, 190);
		// timer.scheduleAtFixedRate(timerTask2, 0, 25*100);
		System.out.println("TimerTask started");
		// cancel after sometime
		try {
			// Une boucle for version java 8...
			//To test parallele calls 
			//IntStream.range(1, 5).parallel().forEach
			IntStream.range(1, 5).forEach(i -> {
				try {
					System.out.println(i + " : ===> Price :" + movingItem.getPrice()) ;
					Thread.sleep(200);
					System.out.println(i + " : ===> Price has changed :" + movingItem.getPrice()) ;
				} catch (InterruptedException ex) {
				}
				System.out.println(i);
			});
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		timer.cancel();
		System.out.println("TimerTask cancelled");
	}
}
