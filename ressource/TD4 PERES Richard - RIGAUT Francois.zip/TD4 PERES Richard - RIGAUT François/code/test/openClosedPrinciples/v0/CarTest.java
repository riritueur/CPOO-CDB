package openClosedPrinciples.v0;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CarTest {

	
	Car myCar = new Car("1111 AB 06",50);
	LocalDate currentDate;
	@Before
	public void setUp() throws Exception {
		//To be sure that is a new car
	  myCar = new Car("1111 AB 06",50);
	  currentDate = LocalDate.of(2017, 9, 17);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIsAvailableDateWhenNoReservation() {
		assertTrue("Available new car", myCar.isAvailable(currentDate) );
	}
	
	@Test
	public void testIsAvailableDateFalse() {
		myCar.book(currentDate, 2);
		assertFalse("no more available " , myCar.isAvailable(currentDate) );
		assertFalse("no more available " , myCar.isAvailable(LocalDate.of(2017, 9, 17)) );
		assertFalse("no more available one day later" , myCar.isAvailable(DateTools.addDays(currentDate, 1)) );
	}
	
	@Test
	public void testIsAvailableDateTrue() {
		myCar.book(currentDate, 2);
		assertTrue(myCar.isAvailable(DateTools.addDays(currentDate, 2) ) );
		assertTrue(myCar.isAvailable(DateTools.addDays(currentDate, 3) ) );
	}

	@Test
	public void testBook() {
		assertEquals(0, myCar.getRentals().size());
		myCar.book(currentDate, 2);
		assertEquals(2, myCar.getRentals().size());
		assertTrue(myCar.getRentals().contains(currentDate));
	}

	@Test
	public void testIsAvailableDateArray() {
		myCar.book(currentDate, 2);
		LocalDate nd = LocalDate.of(2017, 9, 17);
		LocalDate[] dates = {nd, DateTools.addDays(nd, 1), DateTools.addDays(nd, 2)};
		assertFalse(myCar.isAvailable(dates));
		assertTrue(myCar.isAvailable(DateTools.addDays(nd, 3)));
	}

}
