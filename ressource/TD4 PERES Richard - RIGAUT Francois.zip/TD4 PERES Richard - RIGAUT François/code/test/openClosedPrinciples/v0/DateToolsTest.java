package openClosedPrinciples.v0;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DateToolsTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddDays() {
		LocalDate d = LocalDate.of(2017, 9, 17);
		LocalDate dMore = DateTools.addDays(d, 5);
		assertEquals(22, dMore.getDayOfMonth());
	}
	
	@Test
	public void testgetDays() {
		LocalDate d = LocalDate.of(2017, 9, 17);
		LocalDate[] dMore = DateTools.getDays(d, 5);
		assertEquals("5 date are added", 5, dMore.length);
		assertEquals(d, dMore[0]);
		assertEquals(d.getDayOfMonth() +2 , dMore[2].getDayOfMonth());
		assertEquals(d.getDayOfMonth() +4 , dMore[4].getDayOfMonth());
	}

}
