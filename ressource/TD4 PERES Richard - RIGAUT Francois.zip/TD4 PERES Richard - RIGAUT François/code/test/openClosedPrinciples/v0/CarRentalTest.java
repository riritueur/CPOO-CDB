package openClosedPrinciples.v0;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CarRentalTest {

	
	Car myCar = new Car("1111 AB 06",50);
	Car myCar2 = new Car("1111 AB 06",60);
	Car myCar3 = new Car("1111 AB 06",40);
	CarRental carRental;
	
	@Before
	public void setUp() throws Exception {
		myCar = new Car("1111 AB 06",50);
		myCar2 = new Car("1111 AB 06",60);
		myCar3 = new Car("1111 AB 06",40);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCarRental() {
		carRental = new CarRental(myCar, LocalDate.of(2017, 8, 31), 3);
		Set<LocalDate> reservations = myCar.getRentals();
		assertEquals(3,reservations.size());
	}

	@Test
	public void testGetPrice() {
		carRental = new CarRental(myCar, LocalDate.of(2017, 8, 31), 3);
		assertEquals(50*3,carRental.getPrice(),0);
	}
	
	@Test
	public void testSortedByPrice(){
		ArrayList<CarRental> carRentals = new ArrayList<CarRental>();
		carRentals.add(new CarRental(myCar, LocalDate.of(2017, 8, 31), 3));
		carRentals.add(new CarRental(myCar2, LocalDate.of(2017, 8, 31), 3));
		carRentals.add(new CarRental(myCar3, LocalDate.of(2017, 8, 31), 3));
		Tools.sortedByPrice(carRentals);
		assertTrue((int)Tools.cheaper(carRentals).getPrice() == carRentals.get(0).getPrice());
	}

}
