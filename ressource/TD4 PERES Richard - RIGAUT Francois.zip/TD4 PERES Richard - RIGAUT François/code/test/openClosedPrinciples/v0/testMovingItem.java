package openClosedPrinciples.v0;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.stream.IntStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class testMovingItem {

	ArrayList<Flight> flights;
	Flight flight;
	Flight flight1;
	Flight flight2;
	FlightService fs;
	
	@Before
	public void setUp() throws Exception {
		flights = new ArrayList<>();
		flight = new Flight(20, LocalDate.of(2017, 8, 1), LocalTime.of(8, 30), "Nice", "Paris");
		flight1 = new Flight(10, LocalDate.of(2017, 8, 1), LocalTime.of(9, 30), "Nice", "Paris");
		flight2 = new Flight(30, LocalDate.of(2017, 8, 1), LocalTime.of(10, 30), "Nice", "Paris");
		flights.add(flight);
		flights.add(flight1);
		flights.add(flight2);
		fs = new FlightService(flights);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFindMovingItem() {
		Description d = new Description(LocalDate.of(2017, 8, 1), "Nice", "Paris", 2);
		Flight f = (Flight) fs.find(d);
		//Test pour les noms
		System.out.println(flight.getName());
		System.out.println(flight1.getName());
		System.out.println(flight2.getName());
		// Test pour une nouvelle boucle for utilisant un forEach
		IntStream.range(1, 5).forEach(i -> {
			try {
				// Pour visualiser que le prix change bien.
				// Il est difficile de le definir spus la forme d'Asset
				// car on ne sait pas combien de fois le ratio a eu le temps de s'appliquer
				// L'attente permet � la tache en arri�re plan de s'ex�cuter
				System.out.println(i + " : ===> Price :" + f.getPrice());
				Thread.sleep(200);
				System.out.println(i + " : ===> Price has changed :" + f.getPrice());
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			System.out.println(i);
		});
	}
}
