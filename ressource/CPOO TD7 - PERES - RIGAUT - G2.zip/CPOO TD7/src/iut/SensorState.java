package iut.sensors;

//Etat d'un capteur logiciel
public interface SensorState {
	public String getValue(LogicalSensorWithState l);
}
