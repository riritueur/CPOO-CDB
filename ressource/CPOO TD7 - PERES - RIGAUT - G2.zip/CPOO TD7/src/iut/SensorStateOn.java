package iut.sensors;

import memoryPK.MalFormatteeCapteurException;

//Etat on d'un capteur logiciel
public class SensorStateOn implements SensorState{

	@Override
	public String getValue(LogicalSensorWithState l) {
		try{
			return l.physSens().getValue() + " �C";
		}catch(NonAccessibleSensorException e){
			return "bad value";
		}catch(MalFormatteeCapteurException e){
			return "bad value";
		}
	}

}
