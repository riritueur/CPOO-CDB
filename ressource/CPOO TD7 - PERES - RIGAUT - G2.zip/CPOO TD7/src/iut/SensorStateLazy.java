package iut.sensors;

import memoryPK.MalFormatteeCapteurException;

//Etat lazy d'un capteur logiciel
public class SensorStateLazy implements SensorState{

	@Override
	public String getValue(LogicalSensorWithState l) {
		if(System.currentTimeMillis() - l.timeLastUpdate() < 100){
			try{
				return l.physSens().getValue() + " �C";
			}catch(NonAccessibleSensorException e){
				return "bad value";
			}catch(MalFormatteeCapteurException e){
				return "bad value";
			}
		}
		else
			return "lazy";
	}

}
