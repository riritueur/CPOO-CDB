package iut.sensors;

//Liste des �tats possibles d'un robot
public enum RobotState {
	Rest, Control, Surveillance, Alert;
}
