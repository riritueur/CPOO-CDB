package iut.sensors;

//Un capteur logiciel qui ne poss�de qu'un bouton pour changer d'�tat
public class LogicalSensorOneButton extends LogicalSensorWithState{
	
	private boolean pressed;

	public LogicalSensorOneButton(PhysicalSensor physSens, String unit) {
		super(physSens, unit);
		pressed = false;
	}
	
	public void pressButton(){
		if(pressed){
			SensorState localstate = state();
			if(localstate instanceof SensorStateOff)
				ownOn();
			if(localstate instanceof SensorStateOn)
				ownLazy();
			if(localstate instanceof SensorStateLazy)
				ownOff();
		}
		else if(!pressed)
			pressed = true;
		else{
			System.out.println("Erreur nbPressed");
			pressed = false; // "D�bogage auto"
		}
	}
	
	private void ownOn(){super.on(); pressed = false;}
	private void ownOff(){super.off(); pressed = false;}
	private void ownLazy(){super.lazy(); pressed = false;}
	
	/*** Pour emp�cher l'utilisation directe de on(), off() et lazy() ***/
	@Override
	public void on(){}
		
	@Override
	public void off(){}
	
	@Override
	public void lazy(){}

}
