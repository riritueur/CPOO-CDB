package iut.sensors;

import java.util.Observable;
import java.util.Observer;

//Un tableau qui surveille un lieu et qui permet d'afficher les valeurs de tous ses capteurs.
public class TableauBord implements Observer{
	private Lieu place;
	
	public TableauBord(Lieu place){
		this.place = place;
		place.addAllObservers(this);
	}
	
	//Pour afficher les donn�es de tous les capteurs du lieu.
	public void printData(){
		System.out.println("Tableau de bord - " + place.name() + ":\n" + place.toString());
	}

	//On r�affiche toutes les donn�es � chaque modification d'un capteur.
	@Override
	public void update(Observable o, Object arg) {
		printData();
	}
}
