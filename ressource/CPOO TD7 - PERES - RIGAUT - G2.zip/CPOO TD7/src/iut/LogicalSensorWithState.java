package iut.sensors;

//Capteur logiciel qui change d'�tat sur commande
public class LogicalSensorWithState extends LogicalSensor{
	
	private SensorState state;
	private long timeLastUpdate;
	
	public LogicalSensorWithState(PhysicalSensor physSens, String unit){
		super(physSens, unit);
		state = new SensorStateOff();
	}	
	
	public long timeLastUpdate(){return timeLastUpdate;}
	public SensorState state(){return state;}
	
	@Override
	public void setValue(String value){
		try {
			physSens().setValue(value);
			timeLastUpdate = System.currentTimeMillis();
		} catch (NonAccessibleSensorException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public String value(){return state.getValue(this);}
	
	public void on(){state = null; state = new SensorStateOn();}
	public void off(){state = null; state = new SensorStateOff();}
	public void lazy(){state = null; state = new SensorStateLazy();}
}
