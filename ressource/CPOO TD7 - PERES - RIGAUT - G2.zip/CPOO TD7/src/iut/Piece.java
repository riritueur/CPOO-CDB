package iut.sensors;

import java.util.ArrayList;

//Une piece est un espace simple pouvant comporter des capteurs
public class Piece extends Espace{
	
	public Piece(String name){
		super(name);
	}
	
	public String toString(){
		String sensorList = super.toString();
		ArrayList<LogicalSensor> localsensors = sensors();
		for(LogicalSensor ls : localsensors)
			sensorList += ls.toString() + "\n";
		return name() + ":\n" + sensorList;
	}
}
