package iut.sensors;

import java.util.ArrayList;
import java.util.Observer;

//Une maison est un lieu qui poss�de des espaces (partie ou pieces)
public class MaisonNumerique extends Lieu{
	//Une piece peut etre independante d'une partie
	private ArrayList<Espace> spaces;
	
	public MaisonNumerique(String name){
		super(name);
		spaces = new ArrayList<Espace>();
	}

	public void addSpace(Espace space){spaces.add(space);}
	
	@Override
	public String toString(){
		String res = name() + "\n";
		for(Espace e : spaces)
			res += e.toString();
		return res;
	}
	
	//R�cup�re les capteurs de tous les espaces
	@Override
	public ArrayList<LogicalSensor> sensors(){
		ArrayList<LogicalSensor> res = new ArrayList<LogicalSensor>();
		for(Espace e : spaces)
			res.addAll(e.sensors());
		return res;
	}
	
	//Pour ajouter l'observer a tous les capteurs des espaces
	@Override
	public void addAllObservers(Observer o){
		addObserver(o);
		for(Espace e : spaces)
			e.addAllObservers(o);
	}
}
