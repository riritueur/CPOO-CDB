package iut.sensors;

import java.util.ArrayList;
import java.util.Observer;

//Une partie est un espace composite contenant des pieces ou d'autres parties
public class Partie extends Espace{
	
	private ArrayList<Espace> spaces;
	
	public Partie(String name){
		super(name);
		spaces = new ArrayList<Espace>(); 
	}
	
	//R�cup�re les sensors de tous les espaces
	@Override
	public ArrayList<LogicalSensor> sensors(){
		ArrayList<LogicalSensor> res = new ArrayList<LogicalSensor>();
		res.addAll(super.sensors());
		for(Espace e : spaces)
			res.addAll(e.sensors());
		return res;
	}
	
	public void addSpace(Espace space){spaces.add(space);}
	
	public String toString(){
		String sensorList = super.toString() + "\n";
		String spacesStrings = "\n";
		ArrayList<LogicalSensor> localsensors = sensors();
		for(LogicalSensor ls : localsensors)
			sensorList += " - " + ls.toString() + "\n";
		for(Espace e : spaces)
			spacesStrings += e.toString();
		return name() + ":" + sensorList + "\n---\n" + spacesStrings;
	}
	
	//Pour ajouter l'observer � tous les espaces contenus
	@Override
	public void addAllObservers(Observer o){
		addObserver(o);
		for(Espace e : spaces)
			e.addAllObservers(o);
	}
}
