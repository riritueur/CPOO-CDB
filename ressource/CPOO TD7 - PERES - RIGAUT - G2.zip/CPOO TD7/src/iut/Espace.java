package iut.sensors;

//Un espace est une piece ou une partie.
public abstract class Espace extends Lieu{
	
	public Espace(String name){
		super(name);
	}
}
