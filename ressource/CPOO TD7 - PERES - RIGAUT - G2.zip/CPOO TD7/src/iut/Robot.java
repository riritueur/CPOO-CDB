package iut.sensors;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Observable;
import java.util.Observer;

//Un robot qui effectue des analyses d'une maison et qui d�clenche des alarmes si certains capteurs sont modifi�s.
public class Robot implements Observer{
	private String name;
	private RobotState state;
	private MaisonNumerique house;
	private ArrayList<LogicalSensor> dedicated;
	private ArrayList<String> initialValues;
	
	//Ce constructeur d�die tous les capteurs de la maison au robot
	public Robot(String name, MaisonNumerique house){
		this.name = name;
		this.house = house;
		state = RobotState.Rest;
		dedicated = house.sensors();
		initialValues = new ArrayList<String>();
		
	}
	
	//L'arraylist pass�e en param�tre comporte les capteurs que le robot doit surveiller une fois en fois surveillance.
	//Ils doivent appartenir � la maison donn�e en apram�tre.
	public Robot(String name, MaisonNumerique house, ArrayList<LogicalSensor> dedicated) throws Throwable{
		this(name, house);
		if(house.sensors().containsAll(dedicated)){
			this.dedicated = dedicated;
		}
		else{
			throw new Throwable("Les capteurs d�di�s doivent etre pr�sents dans la maison");
		}
	}
	
	//Mode repos
	public void restMode(){
		if(state.equals(RobotState.Alert)){
			System.out.println("Retour en mode repos.");
			state = RobotState.Rest;
		}
		else if(state.equals(RobotState.Rest))
			System.out.println("Le robot est d�ja en mode repos.");
		else
			System.out.println("Passage en mode repos possible uniquement si le robot est en mode alerte.");
	}
	
	//Mode controle
	public void controlMode(){
		if(state.equals(RobotState.Rest)){
			state = RobotState.Control;
			System.out.println("Passage en mode controle.");
			analyze();
		}
		else
			System.out.println("Passage en mode controle possible uniquement si le robot est en mode repos.");
	}
	
	//Mode surveillance, appel� uniquement � la fin d'une analyse ou au retour du mode alerte.
	private void surveillanceMode(){
		System.out.println("Passage en mode surveillance.");
		state = RobotState.Surveillance;
		if(initialValues.isEmpty()){
			for(LogicalSensor l : dedicated){
				l.addObserver(this);
				initialValues.add(l.value());
			}
		}
	}
	
	//Mode alerte, appel� uniquement pendant le mode surveillance
	private void alertMode(){
		state = RobotState.Alert;
	}
	
	@Override
	public String toString(){
		return "Robot - " + name + ": Mode " + state;
	}

	// Lance une analyse des capteurs de la maison et affiche leurs r�sultats. Appel�e uniquement pas la m�thode controlMode().
	// Nous avons essay� de le multithreader, mais la classe de tests se terminait avant la m�thode
	// Et le Thread.sleep ne fonctionnait pas... On ne peut donc pas interrompre l'analyse, malheureusement.
	private void analyze(){
		System.out.println("D�but de l'analyse...");
		ArrayList<LogicalSensor> sensors = house.sensors();
		int size = sensors.size();
		int progress = 0;
		boolean completed = false;
		SimpleDateFormat formatHeure = new SimpleDateFormat("HH:mm:ss");
		Calendar c;
		while (!completed) {
			try {
				if(progress >= size){
					completed = true;
				}
				else{
					c = Calendar.getInstance();
					System.out.println(formatHeure.format(c.getTime()) + ": " + sensors.get(progress));
					progress++;
					if(progress < size){
						Thread.sleep(1000);
					}
				}
			} catch (InterruptedException e) {
				System.out.println("Interrupted");
			}
		}
		surveillanceMode();
	}

	//Pour v�rifier si les valeurs ont �t� modifi�es par rapport � celles de d�part.
	//Appel�e uniquement par la m�thode update
	private boolean verifyValues(){
		int i=0;
		for(LogicalSensor l : dedicated){
			if(!l.value().equals(initialValues.get(i))){
				return false;
			}
			i++;
		}
		return true;
	}
	
	//Pour capter les changements de valeurs dans les capteurs d�di�s.
	@Override
	public void update(Observable arg0, Object arg1) {
		if(!verifyValues() && state.equals(RobotState.Surveillance)){
			System.out.println("/!\\ Alarme d�clench�e /!\\\n--- Passage en mode alerte ---");
			alertMode();
		}
		else{
			if(verifyValues() && state.equals(RobotState.Alert)){
				System.out.println("Capteurs revenus � la normale. Retour en mode surveillance...");
				surveillanceMode();
			}
		}
	}
	
	public RobotState mode(){return state;}
}
