package iut.sensors;

import java.io.IOException;

public class NonAccessibleSensorException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private PhysicalSensor capteurPhysique;
	private IOException exception;

	public NonAccessibleSensorException(PhysicalSensor capteurPhysique,
			IOException e) {
		this.capteurPhysique  = capteurPhysique;
		this.exception = e;
	}
	
	 public String getMessage()
	    {
	        return super.getMessage() + capteurPhysique.getName() + "avec" + exception;
	    }

	
	
	
	

}
