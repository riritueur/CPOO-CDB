package iut.sensors;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

//Un lieu est une maison ou une espace. 
public abstract class Lieu extends Observable implements Observer{
	private String name;
	//Les capteurs propres au lieu.
	private ArrayList<LogicalSensor> sensors;
	
	public Lieu(String name){
		this.name = name;
		sensors = new ArrayList<LogicalSensor>();
	}
	
	public void addSensor(LogicalSensor ls){
		sensors.add(ls);
		ls.addObserver(this);
		setChanged();
		notifyObservers();
	}
	
	@Override
	public String toString(){
		return name + "\n ";
	}
	
	public ArrayList<LogicalSensor> sensors(){return sensors;}
	
	public String name(){return name;}
	
	//M�thode � overrider pour ajouter l'observer aux espaces contenus
	public void addAllObservers(Observer o){
		addObserver(o);
	}
	
	//On notifie les observers lorsqu'un capteur est chang�
	@Override
	public void update(Observable o, Object arg) {
		setChanged();
		notifyObservers();
	}
}
