package iut.sensors;

import java.util.Observable;

import memoryPK.MalFormatteeCapteurException;

//Un capteur logiciel qui traite les donn�es d'un capteur physique
public class LogicalSensor extends Observable{
	private PhysicalSensor physSens;
	private String unit;
	
	//On associe une unit� au capteur logiciel pour un affichage plus propre
	public LogicalSensor(PhysicalSensor physSens, String unit){
		this.physSens = physSens;
		this.unit = unit;
	}
	
	public String value(){
		try {
			return physSens.getValue() + " " + unit;
		} catch (NonAccessibleSensorException | MalFormatteeCapteurException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public PhysicalSensor physSens(){return physSens;}
	
	public void setValue(String value){
		try {
			physSens.setValue(value);
			setChanged();
			notifyObservers();
		} catch (NonAccessibleSensorException e) {
			e.printStackTrace();
		}
	}
	
	public String toString(){
		return physSens.getName() + ": " + value();
	}
}
