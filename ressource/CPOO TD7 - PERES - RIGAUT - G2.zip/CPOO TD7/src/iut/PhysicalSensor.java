package iut.sensors;


import java.io.IOException;

import memoryPK.MalFormatteeCapteurException;
import memoryPK.Memory;

/**
 * A physical sensor takes its values in a file whose name is the name of the sensor + .data
  * To facilitate tests, it is possible to modify the value stored by the sensor
 * 
 * @author blay
 *
 */
public class PhysicalSensor {
	
	private String SensorName;
	
	private String nomDuFichier;
	
	
	/**
	 * @return sensor name.
	 */
	public String getName() {
		return SensorName;
	}
  
	
	public String getValue() throws NonAccessibleSensorException, MalFormatteeCapteurException {
		try {
			return (String) Memory.read(nomDuFichier);
		} catch (IOException e) {
			throw new NonAccessibleSensorException(this,e);
		} catch (ClassNotFoundException e) {
			throw new MalFormatteeCapteurException(this,e);
		}
    }
    
    public PhysicalSensor(String name) {
		SensorName = name;
		nomDuFichier= name+".data";
	}

	public void setValue(String value) throws NonAccessibleSensorException {
		try {
			Memory.save(value, nomDuFichier);
		} catch (IOException e) {
			throw new NonAccessibleSensorException(this,e);
		}
    }
	
}
