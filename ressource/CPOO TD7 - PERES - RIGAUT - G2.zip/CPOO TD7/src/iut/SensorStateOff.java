package iut.sensors;

//Etat off d'un capteur logiciel
public class SensorStateOff implements SensorState{

	@Override
	public String getValue(LogicalSensorWithState l) {
		return "off";
	}

}
