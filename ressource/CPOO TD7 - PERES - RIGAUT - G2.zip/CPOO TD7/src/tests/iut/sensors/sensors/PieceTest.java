package tests.iut.sensors;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import iut.sensors.LogicalSensor;
import iut.sensors.LogicalSensorOneButton;
import iut.sensors.LogicalSensorWithState;
import iut.sensors.PhysicalSensor;
import iut.sensors.Piece;

public class PieceTest {
	
	PhysicalSensor thermometre1;
	PhysicalSensor thermometre2;
	LogicalSensor lcp1;
	LogicalSensor lcp2;
	LogicalSensorWithState lcpState;
	LogicalSensorOneButton lcpOB;
	Piece piece;

	@Before
	public void setUp() throws Exception {
		thermometre1 = new PhysicalSensor("thermometre1");
		thermometre2 = new PhysicalSensor("thermometre2");
		lcp1 = new LogicalSensor(thermometre1, "�C");
		lcp1.setValue("18");
		lcp2 = new LogicalSensor(thermometre2, "�C");
		lcp2.setValue("35");
		lcpState = new LogicalSensorWithState(thermometre1, "�C");
		lcpState.setValue("18");
		lcpOB = new LogicalSensorOneButton(thermometre1, "�C");
		lcpOB.setValue("18");
		piece = new Piece("Salon");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws InterruptedException {
		piece.addSensor(lcp1);
		piece.addSensor(lcp2);
		piece.addSensor(lcpState);
		lcpOB.pressButton();
		lcpOB.pressButton();
		lcpOB.pressButton();
		lcpOB.pressButton();
		Thread.sleep(500);
		piece.addSensor(lcpOB);
		System.out.println(piece.toString());
	}

}
