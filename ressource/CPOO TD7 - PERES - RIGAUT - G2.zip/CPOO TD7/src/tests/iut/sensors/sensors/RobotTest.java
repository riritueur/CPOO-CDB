package tests.iut.sensors;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import iut.sensors.LogicalSensor;
import iut.sensors.MaisonNumerique;
import iut.sensors.Partie;
import iut.sensors.PhysicalSensor;
import iut.sensors.Piece;
import iut.sensors.Robot;

public class RobotTest{

	private MaisonNumerique maison;
	private Partie rdc;
	private Piece cuisine;
	private Piece sam;
	private Partie parentalPart;
	private Piece chambreParents;
	private Piece sdbParent;
	private Partie etage;
	private Partie exterieur;
	private Piece chambre1;
	private Piece chambre2;
	private LogicalSensor thermostatParental;
	private LogicalSensor externeDetecteurLumiere;
	private LogicalSensor rdcThermo;
	private LogicalSensor cuisineThermo;
	private LogicalSensor samThermo;
	private Robot robot;
	ArrayList<LogicalSensor> dedicated;
	
	
	@Before
	public void setUp() throws Exception {
		thermostatParental = new LogicalSensor(new PhysicalSensor("thermostatParental"), "�C");
		externeDetecteurLumiere = new LogicalSensor(new PhysicalSensor("externeDetecteurLumiere"), "lumen");
		rdcThermo = new LogicalSensor(new PhysicalSensor("rdcThermo"), "�C");
		cuisineThermo = new LogicalSensor(new PhysicalSensor("cuisineThermo"), "�C");
		samThermo = new LogicalSensor(new PhysicalSensor("samThermo"), "�C");
		
		
		thermostatParental.setValue("18");
		externeDetecteurLumiere.setValue("25");
		rdcThermo.setValue("31");
		cuisineThermo.setValue("-2");
		samThermo.setValue("196884");
		
		maison = new MaisonNumerique("Super maison ultra-�quip�e qui vaut 10M �");
		rdc = new Partie("RDC");
		cuisine = new Piece("Cusine");
		sam = new Piece("Salle a manger");

		sam.addSensor(samThermo);
		rdc.addSensor(rdcThermo);
		cuisine.addSensor(cuisineThermo);
		
		parentalPart = new Partie("Partie Parentale");
		chambreParents = new Piece("parents");
		sdbParent = new Piece("salle de bain des parents");
		parentalPart.addSpace(chambreParents);
		parentalPart.addSpace(sdbParent);
		parentalPart.addSensor(thermostatParental);

		rdc.addSpace(cuisine);
		rdc.addSpace(sam);
		rdc.addSpace(parentalPart);


		etage = new Partie("Etage");
		chambre1 = new Piece("Chambre1");
		chambre2 = new Piece("Chambre2");
		etage.addSpace(chambre2);
		etage.addSpace(chambre1);

		exterieur = new Partie("Exterieur");
		exterieur.addSensor(externeDetecteurLumiere);
		maison.addSpace(rdc);
		maison.addSpace(etage);
		maison.addSpace(exterieur);
				
		dedicated = new ArrayList<LogicalSensor>();
		dedicated.add(externeDetecteurLumiere);
		dedicated.add(thermostatParental);
		
		try {
			robot = new Robot("Robot ultra cher qui vaut 2x le prix de la maison", maison, dedicated);
		} catch (Throwable e) {
			System.out.println(e.getMessage());
		}
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testEtats() {
		System.out.println(robot.mode());
		//Passage en mode controle et analyse des pieces
		robot.controlMode();
		System.out.println(robot.mode());
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//Test mode repos si le robot est en surveillance
		robot.restMode();
		System.out.println("D�clenchement de l'alarme.");
		externeDetecteurLumiere.setValue("123");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Changement de valeur du capteur.");
		externeDetecteurLumiere.setValue("122");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Retour � la normale.");
		externeDetecteurLumiere.setValue("25");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("D�clenchement de l'alarme.");
		externeDetecteurLumiere.setValue("132");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//Retour en mode repos
		robot.restMode();
		//Robot deja en repos
		robot.restMode();
	}

}
