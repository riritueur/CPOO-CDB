/**
 * 
 */
package tests.iut.sensors;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import iut.sensors.LogicalSensor;
import iut.sensors.MaisonNumerique;
import iut.sensors.Partie;
import iut.sensors.PhysicalSensor;
import iut.sensors.Piece;
import iut.sensors.TableauBord;

/**
 * @author Francois Rigaut
 *
 */
public class TabBordTest {

	private MaisonNumerique maison;
	private Partie rdc;
	private Piece cuisine;
	private Piece sam;
	private Partie parentalPart;
	private Piece chambreParents;
	private Piece sdbParent;
	private Partie etage;
	private Partie exterieur;
	private Piece chambre1;
	private Piece chambre2;
	private LogicalSensor thermostatParental;
	private LogicalSensor externeDetecteurLumiere;
	private LogicalSensor rdcThermo;
	private LogicalSensor cuisineThermo;
	private LogicalSensor samThermo;
	private TableauBord tbRDC;
	private TableauBord tbCuisine;
	private TableauBord tbMaison;

	@Before
	public void setUp() throws Exception {
		thermostatParental = new LogicalSensor(new PhysicalSensor("thermostatParental"), "�C");
		externeDetecteurLumiere = new LogicalSensor(new PhysicalSensor("externeDetecteurLumiere"), "lumen");
		rdcThermo = new LogicalSensor(new PhysicalSensor("rdcThermo"), "�C");
		cuisineThermo = new LogicalSensor(new PhysicalSensor("cuisineThermo"), "�C");
		samThermo = new LogicalSensor(new PhysicalSensor("samThermo"), "�C");
		
		thermostatParental.setValue("18");
		externeDetecteurLumiere.setValue("25");
		rdcThermo.setValue("31");
		cuisineThermo.setValue("-2");
		samThermo.setValue("196884");
		
		maison = new MaisonNumerique("Super maison ultra-�quip�e qui vaut 10M �");
		rdc = new Partie("RDC");
		cuisine = new Piece("Cusine");
		sam = new Piece("Salle a manger");

		parentalPart = new Partie("Partie Parentale");
		chambreParents = new Piece("Chambre parents");
		sdbParent = new Piece("salle de bain des parents");
		parentalPart.addSpace(chambreParents);
		parentalPart.addSpace(sdbParent);
		parentalPart.addSensor(thermostatParental);

		rdc.addSpace(cuisine);
		rdc.addSpace(sam);
		rdc.addSpace(parentalPart);


		etage = new Partie("Etage");
		chambre1 = new Piece("Chambre1");
		chambre2 = new Piece("Chambre2");
		etage.addSpace(chambre2);
		etage.addSpace(chambre1);

		exterieur = new Partie("Exterieur");
		exterieur.addSensor(externeDetecteurLumiere);
		maison.addSpace(rdc);
		maison.addSpace(etage);
		maison.addSpace(exterieur);
		
		rdc.addSensor(rdcThermo);
		cuisine.addSensor(cuisineThermo);
		
		tbRDC = new TableauBord(rdc);
		tbCuisine = new TableauBord(cuisine);
		tbMaison = new TableauBord(maison);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testPrintData() {
		System.out.println("\n---------------\n-----TBRDC-----\n---------------\n");
		tbRDC.printData();
		System.out.println("\n---------------\n-----TBCUI-----\n---------------\n");
		tbCuisine.printData();
		System.out.println("\n---------------\n-----TBMAI-----\n---------------\n");
		tbMaison.printData();
	}
	
	@Test
	public void testObservables(){
		sam.addSensor(samThermo);
		System.out.println("\n---------------\n-----MODIF SAMTHERMO-----\n---------------\n");
		samThermo.setValue("17");
	}

}
