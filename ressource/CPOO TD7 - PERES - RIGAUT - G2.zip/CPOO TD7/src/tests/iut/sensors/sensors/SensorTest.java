package tests.iut.sensors;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import org.junit.Before;
import org.junit.Test;

import iut.sensors.LogicalSensor;
import iut.sensors.LogicalSensorWithState;
import iut.sensors.NonAccessibleSensorException;
import iut.sensors.PhysicalSensor;
import iut.sensors.LogicalSensorOneButton;
import memoryPK.MalFormatteeCapteurException;

public class SensorTest {

	PhysicalSensor cpPermanent = new PhysicalSensor("cpPermanent");
	PhysicalSensor cpTemporaire;
	LogicalSensor lcpTemporaire;
	LogicalSensorWithState lcpState;
	LogicalSensorOneButton lcpOB;
	String nomCapteur= "cp1";
	
	PhysicalSensor ps = new PhysicalSensor("mySensorLux");
	
	@Before
	public void setUp() throws Exception {
		cpTemporaire = new PhysicalSensor(nomCapteur);
		lcpTemporaire = new LogicalSensor(cpTemporaire, "�C");
		lcpTemporaire.setValue("18");
		lcpState = new LogicalSensorWithState(cpTemporaire, "�C");
		lcpState.setValue("18");
		lcpOB = new LogicalSensorOneButton(cpTemporaire, "�C");
		lcpOB.setValue("18");
	}

	

	@Test(expected = NonAccessibleSensorException.class)
	public void testAccessProblem() throws MalFormatteeCapteurException, NonAccessibleSensorException {
		PhysicalSensor cpPermanentError = new PhysicalSensor("cpPermanentError");
		cpPermanentError.getValue();
	}
	
	
	@Test
	public void testCapteurSetValeur() throws IOException, NonAccessibleSensorException, ClassNotFoundException {
		cpTemporaire.setValue("12.2");
	    FileInputStream fichier = new FileInputStream(nomCapteur+".data");
	    ObjectInputStream ois = new ObjectInputStream(fichier);
        String val = (String) ois.readObject();
        ois.close();
		assertEquals("12.2", val);
	}
	
	
	
    @Test
	public void testCapteurFichierRenseigne() throws IOException, NonAccessibleSensorException, MalFormatteeCapteurException {
		cpTemporaire.setValue("12.2");
		String val = cpTemporaire.getValue();
		String expected = "12.2";
		assertEquals(expected, val);
	}
    
    @Test
    public void testCapteurLogiciel() throws NonAccessibleSensorException{
    	cpTemporaire.setValue("12.2");
    	String val = lcpTemporaire.value();
    	String expected = "12.2 �C";
    	assertEquals(expected, val);
    }
    
    @Test
	public void testStateInit() {
		assertEquals("Off at the beginning","off",lcpState.value());
	}
 
	@Test
	public void testStateOn() throws IOException, NonAccessibleSensorException {
		lcpState.on();
		assertEquals("On","18 �C",lcpState.value());
		lcpState.setValue("20");
		assertEquals("On","20 �C",lcpState.value());
	}
 
	@Test
	public void testStateOnOff() throws IOException, NonAccessibleSensorException {
		lcpState.on();
		assertEquals("On","18 �C",lcpState.value());
		lcpState.off();
		assertEquals("off",lcpState.value());
	}
 
	@Test
	public void testStateLazy() throws IOException, NonAccessibleSensorException, InterruptedException {
		lcpState.lazy();
		lcpState.setValue("18");
		assertEquals("18 �C",lcpState.value());
		lcpState.setValue("20");
		assertEquals("Wake up : value modified", "20 �C", lcpState.value());
	    Thread.sleep(150);
		assertEquals("Lazy state : value modified", "lazy",  lcpState.value() );
		lcpState.setValue("20");
		assertEquals("value modified", "20 �C",  lcpState.value() );
	}
	
	@Test
	public void testOneButton() throws InterruptedException{
		assertEquals("Off at the beginning","off",lcpOB.value());
		lcpOB.pressButton();
		lcpOB.pressButton();
		lcpOB.setValue("18");
		assertEquals("18 �C",lcpOB.value());
		lcpOB.pressButton();
		lcpOB.pressButton();
		lcpOB.setValue("20");
		assertEquals("wake up : value modified", "20 �C", lcpOB.value());
	    Thread.sleep(150);
		assertEquals("Lazy state : value modified", "lazy",  lcpOB.value() );
		lcpOB.setValue("20");
		assertEquals("value modified", "20 �C",  lcpOB.value() );
	}

}

