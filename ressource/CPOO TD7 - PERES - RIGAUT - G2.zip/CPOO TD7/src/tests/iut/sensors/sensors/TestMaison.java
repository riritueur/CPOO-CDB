package tests.iut.sensors;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import iut.sensors.LogicalSensor;
import iut.sensors.MaisonNumerique;
import iut.sensors.Partie;
import iut.sensors.PhysicalSensor;
import iut.sensors.Piece;

public class TestMaison {

	private MaisonNumerique maison;
	private Partie rdc;
	private Piece cuisine;
	private Piece sam;
	private Partie parentalPart;
	private Piece chambreParents;
	private Piece sdbParent;
	private Partie etage;
	private Partie exterieur;
	private Piece chambre1;
	private Piece chambre2;
	private LogicalSensor thermostatParental;
	private LogicalSensor externeDetecteurLumiere;

	@Before
	public void setUp() throws Exception {
		thermostatParental = new LogicalSensor(new PhysicalSensor("thermostatParental"), "�C");
		externeDetecteurLumiere = new LogicalSensor(new PhysicalSensor("externeDetecteurLumiere"), "lumen");
		
		thermostatParental.setValue("18");
		externeDetecteurLumiere.setValue("25");
		
		maison = new MaisonNumerique("Super maison ultra-�quip�e qui vaut 10M �");
		rdc = new Partie("RDC");
		cuisine = new Piece("Cusine");
		sam = new Piece("Salle a manger");

		parentalPart = new Partie("Partie Parentale");
		chambreParents = new Piece("parents");
		sdbParent = new Piece("salle de bain des parents");
		parentalPart.addSpace(chambreParents);
		parentalPart.addSpace(sdbParent);
		parentalPart.addSensor(thermostatParental);

		rdc.addSpace(cuisine);
		rdc.addSpace(sam);
		rdc.addSpace(parentalPart);


		etage = new Partie("Etage");
		chambre1 = new Piece("Chambre1");
		chambre2 = new Piece("Chambre2");
		etage.addSpace(chambre2);
		etage.addSpace(chambre1);

		exterieur = new Partie("Exterieur");
		exterieur.addSensor(externeDetecteurLumiere);
		maison.addSpace(rdc);
		maison.addSpace(etage);
		maison.addSpace(exterieur);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		System.out.println(maison);
	}

}
