package Code;
public class VoitureSansPermis extends Vehicule {
	
	private final static int vitesseMax = 50, poidsVide = 1;
	
	public VoitureSansPermis(String imm){
		super(imm, poidsVide, vitesseMax, "Voiture sans permis");
	}
}