package Code;
public abstract class Vehicule implements Machine{
	
	private String immatriculation;
	private int poidsVide;
	private int vitesseMax;
	private String type;
	private int horsePower = 100; //Puissance arbitraire, nous avons choisi 100 chevaux
	
	//On ne v�rifie pas si un v�hicule avec cette immatriculation existe d�j�, car on ne sait pas, selon les donn�es, s'il faut impl�menter cette fonctionnalit� ou non
	public Vehicule(String imm, int poids, int vitesse, String type){
		this.immatriculation = imm;
		this.poidsVide = poids;
		this.vitesseMax = vitesse;
		this.type = type;
	}
	
	public String getImmatricualtion() { return immatriculation;}
	public int getVitesseMax() { return vitesseMax;}
	public int getPoids() {	return poidsVide;}
	public int getChargeMax() { return 0;}
	
	public void setImmatriculation(String i) { immatriculation = i;}
	public void setVitesseMax(int v) { if(v<Integer.MAX_VALUE)vitesseMax = v;}
	public void setPoidsVide(int p) { poidsVide = p;}
	
	public int getWeight(){
			return this.getPoids();
	}
	
	public int getHorsePower(){
		return this.horsePower;
	}
	
	public String toString(){
		return "Type du v�hicule: " + type + ", immatriculation: " + immatriculation + ", vitesse maximum: " + vitesseMax + ", poids � vide: " + poidsVide; 
	}
}
