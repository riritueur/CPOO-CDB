package Code;

import java.util.ArrayList;

public class Convoi {
	
	private ArrayList<Vehicule> convoi;
	private int vitesseMax;
	private int chargeMax;
	
	public Convoi() {
		convoi = new ArrayList<Vehicule>();
	}
	
	public void ajouterVehicule(Vehicule v) {
		convoi.add(v);
		calculerVitesseMax();
		calculerChargeMax();
	}
	
	public void calculerVitesseMax() {
		int v=convoi.get(0).getVitesseMax();
		for(int i=0; i<convoi.size(); i++){
			if(v > convoi.get(i).getVitesseMax())
				v = convoi.get(i).getVitesseMax() ;
		}
		vitesseMax=v;
	}
	
	public void calculerChargeMax() {
		int c = 0;
		for(int i=0; i<convoi.size(); i++)
			c += convoi.get(i).getChargeMax();
		chargeMax=c;
	}
	
	public int getConsumption(){
		int retour = 0;
		for(int i=0; i<convoi.size(); i++)
			retour += Simulator.consumption(convoi.get(i), this.getVitesseMax());
		return retour;
	}
	
	public int getVitesseMax() { return vitesseMax;}
	public int getChargeMax() { return chargeMax;}
	public ArrayList<Vehicule> getVehicule() { return convoi;}
}
