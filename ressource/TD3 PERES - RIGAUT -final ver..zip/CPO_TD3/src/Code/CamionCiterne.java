package Code;
public class CamionCiterne extends VehiculeTransport {
	
	private final static int chargeMax = 10, poidsVide = 3;

	public CamionCiterne(String imm) {
		super(imm, poidsVide, 0, chargeMax, "Camion citerne");
		calculerVitesse();
	}
	
	public void calculerVitesse() {

		//La vitesse varie en fonction de la charge
		if(getCharge() == 0){
			setVitesseMax(130);
		}
		else if(getCharge() <= 1 ){
			setVitesseMax(110);
		}
		else if(getCharge() <= 4){
			setVitesseMax(90);
		}
		else 
			setVitesseMax(80);
	}
	
	
}
