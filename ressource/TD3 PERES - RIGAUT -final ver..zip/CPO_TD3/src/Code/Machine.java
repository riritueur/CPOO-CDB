package Code;

public interface Machine {
	 int getWeight(); 
	 int getHorsePower();
}