package Code;
public class CamionBache extends VehiculeTransport {
	
	private final static int chargeMax = 20, poidsVide = 4;

	public CamionBache(String imm) {
		super(imm, poidsVide, 0, chargeMax, "Camion bache");
		calculerVitesse();
	}
	
	public void calculerVitesse(){
		
		//La vitesse varie en fonction de la charge
		if(getCharge() == 0){
			setVitesseMax(130);
		}
		else if(getCharge() <= 3 ){
			setVitesseMax(110);
		}
		else if(getCharge() <= 7){
			setVitesseMax(90);
		}
		else 
			setVitesseMax(80);
	}
}
