package Code;
public abstract class VehiculeTransport extends Vehicule {
	
	private int charge;
	private int chargeMax;
	
	public VehiculeTransport(String imm, int poids, int vitesse, int charge, String type) {
		super(imm,poids,vitesse,type);
		this.chargeMax = charge;
		this.charge = 0;
	}
	
	public void calculerVitesse() {}

	public int getCharge() { return charge;}
	public int getChargeMax() { return chargeMax;}
	
	public void setCharge(int c) throws Throwable{ 
		if(c>=0 && c < chargeMax){
			charge = c;
			calculerVitesse();
		}
		else throw new Throwable("Charge invalide\n");
	}
	
	public int getWeight(){
		return super.getPoids() + this.getCharge();
}
	
	public String toString(){
		return super.toString() + ", charge maximum: " + chargeMax + ", charge actuelle: " + charge;
	}
	
	 
}
