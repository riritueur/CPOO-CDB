package Code;
public class PetitBus extends Vehicule {
	
	private final static int vitesseMax = 150, poidsVide = 4;
	
	public PetitBus(String imm){
		super(imm,poidsVide,vitesseMax,"Petit bus");
	}
}