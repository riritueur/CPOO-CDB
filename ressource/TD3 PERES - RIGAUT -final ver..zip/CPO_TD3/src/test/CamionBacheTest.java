package test;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Code.CamionBache;

public class CamionBacheTest {
	
	protected CamionBache cb;

	@Before
	public void setUp() throws Exception {
		cb = new CamionBache("AAA");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws Throwable{
		System.out.println(cb.toString());
		
		assert(cb.getImmatricualtion().equals("AAA"));
		assert(cb.getPoids() == 4);
		assert(cb.getVitesseMax() == 130);
		
		cb.setCharge(3);
		assert(cb.getVitesseMax() == 110);
		cb.setCharge(7);
		assert(cb.getVitesseMax() == 90);
		cb.setCharge(15);
		assert(cb.getVitesseMax() == 80);
		
		cb.setImmatriculation("BBB");
		assert(cb.getImmatricualtion().equals("BBB"));
	}

}
