package test;


import org.junit.Test;
import Code.*;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;


public class ConvoiTest {
	
	protected Convoi c;
	protected PetitBus b;
	protected VoitureSansPermis v;
	protected CamionCiterne cc;
	protected CamionBache cb;
	
	@Before
	public void setUp() throws Exception {
		b = new PetitBus("AAA");
		cc = new CamionCiterne("BBB");
		cb = new CamionBache("CCC");
		v = new VoitureSansPermis("VVV");
		c = new Convoi();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws Throwable{
		cc.setCharge(3);
		cb.setCharge(5);
		c.ajouterVehicule(b);
		c.ajouterVehicule(cc);
		c.ajouterVehicule(cb);
		c.ajouterVehicule(v);
		
		for(int i=0;i<c.getVehicule().size();i++)
			System.out.println(c.getVehicule().get(i).toString());
		
		
		assertEquals(c.getChargeMax(), 30);
		assertEquals(c.getVitesseMax(), 50);
		System.out.println(c.getConsumption());
		assert(c.getConsumption() == Simulator.consumption(b, c.getVitesseMax()) + Simulator.consumption(cc, c.getVitesseMax()) + Simulator.consumption(cb, c.getVitesseMax()) + Simulator.consumption(v, c.getVitesseMax()));
		
	}

}
