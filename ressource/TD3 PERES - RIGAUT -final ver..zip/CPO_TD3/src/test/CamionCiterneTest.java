package test;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Code.CamionCiterne;

public class CamionCiterneTest {
	
	protected CamionCiterne cc;

	@Before
	public void setUp() throws Exception {
		cc = new CamionCiterne("AAA");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws Throwable{
		System.out.println(cc.toString());
		
		assert(cc.getImmatricualtion().equals("AAA"));
		assert(cc.getPoids() == 3);
		assert(cc.getVitesseMax() == 130);
		
		cc.setCharge(1);
		assert(cc.getVitesseMax() == 110);
		cc.setCharge(4);
		assert(cc.getVitesseMax() == 90);
		cc.setCharge(9);
		assert(cc.getVitesseMax() == 80);
		
		cc.setImmatriculation("BBB");
		assert(cc.getImmatricualtion().equals("BBB"));
	}

}
