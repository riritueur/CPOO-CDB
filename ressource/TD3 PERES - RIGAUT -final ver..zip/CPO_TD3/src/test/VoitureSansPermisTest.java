package test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Code.VoitureSansPermis;

public class VoitureSansPermisTest {
	
	protected VoitureSansPermis v;

	@Before
	public void setUp() throws Exception {
		v = new VoitureSansPermis("AAA");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		System.out.println(v.toString());
		
		assert(v.getImmatricualtion().equals("AAA"));
		assert(v.getPoids() == 1);
		assert(v.getVitesseMax() == 50);
		
		v.setImmatriculation("BBB");
		assert(v.getImmatricualtion().equals("BBB"));
	}

}
