package test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Code.PetitBus;

public class PetitBusTest {
	
	protected PetitBus pb;

	@Before
	public void setUp() throws Exception {
		pb = new PetitBus("AAA");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		System.out.println(pb.toString());
		
		assert(pb.getImmatricualtion().equals("AAA"));
		assert(pb.getPoids() == 4);
		assert(pb.getVitesseMax() == 150);
		
		pb.setImmatriculation("BBB");
		assert(pb.getImmatricualtion().equals("BBB"));
	}

}
