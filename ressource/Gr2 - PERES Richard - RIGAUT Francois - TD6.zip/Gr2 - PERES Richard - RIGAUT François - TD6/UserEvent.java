package facebookGhost;

public class UserEvent implements Event {

	User user;
	
	public UserEvent(User user) {
		this.user = user;
	}
	
	
	/*Nous n'arrivions pas � savoir comment update notre r�seau � partir du FbGhost sans cette m�thode et elle n'�tait pas pr�sente dans le code que nous avons r�cup�r�, nous avons donc pens� qu'il s'agissait d'une erreur et avons pris la libert� de l'ajouter nous-m�mes.*/
	public User getUser(){
		return user;
	}

}
